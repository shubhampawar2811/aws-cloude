"""
AWS Storage Helpers
- S3: file upload/download (encrypted files)
- RDS: optional MySQL connection (falls back to SQLite)
"""
import os, base64, uuid

# ── S3 ─────────────────────────────────────────────────────────────
S3_ENABLED  = False
S3_BUCKET   = os.environ.get('S3_BUCKET', '')
_s3_client  = None
_region     = os.environ.get('AWS_REGION', 'ap-south-1')

try:
    import boto3
    _k = os.environ.get('AWS_ACCESS_KEY_ID', '')
    _s = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    if _k and _s and S3_BUCKET:
        _s3_client = boto3.client('s3', region_name=_region,
                                  aws_access_key_id=_k,
                                  aws_secret_access_key=_s)
        S3_ENABLED = True
        print(f"✅  S3 Connected — bucket: {S3_BUCKET}")
    else:
        print("ℹ️   S3 not configured — files stored in DB (set S3_BUCKET env var)")
except Exception as e:
    print(f"ℹ️   S3 unavailable: {e}")


def upload_file_to_s3(file_data_b64: str, file_name: str,
                       instance_id: int, user_id: int) -> str:
    """
    Upload encrypted file to S3.
    Returns S3 key if successful, else None (fall back to DB storage).
    file_data_b64: base64-encoded file bytes
    """
    if not S3_ENABLED:
        return None
    try:
        raw_bytes = base64.b64decode(file_data_b64)
        s3_key    = f"tenants/{instance_id}/users/{user_id}/{uuid.uuid4().hex}_{file_name}"
        _s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=raw_bytes,
            ServerSideEncryption='AES256',   # S3-side encryption too
            Metadata={
                'instance_id': str(instance_id),
                'user_id':     str(user_id),
                'file_name':   file_name,
            }
        )
        return s3_key
    except Exception as e:
        print(f"S3 upload error: {e}")
        return None


def download_file_from_s3(s3_key: str) -> str:
    """Download file from S3 and return base64-encoded bytes"""
    if not S3_ENABLED or not s3_key:
        return None
    try:
        obj  = _s3_client.get_object(Bucket=S3_BUCKET, Key=s3_key)
        raw  = obj['Body'].read()
        return base64.b64encode(raw).decode('utf-8')
    except Exception as e:
        print(f"S3 download error: {e}")
        return None


def delete_file_from_s3(s3_key: str):
    if not S3_ENABLED or not s3_key: return
    try:
        _s3_client.delete_object(Bucket=S3_BUCKET, Key=s3_key)
    except Exception: pass


# ── RDS (optional) ─────────────────────────────────────────────────
RDS_ENABLED = False
_rds_pool   = None

RDS_HOST = os.environ.get('RDS_HOST', '')
RDS_PORT = int(os.environ.get('RDS_PORT', 3306))
RDS_USER = os.environ.get('RDS_USER', '')
RDS_PASS = os.environ.get('RDS_PASSWORD', '')
RDS_DB   = os.environ.get('RDS_DB', 'cloudportal')

try:
    if RDS_HOST and RDS_USER and RDS_PASS:
        import pymysql
        _rds_conn = pymysql.connect(
            host=RDS_HOST, port=RDS_PORT,
            user=RDS_USER, password=RDS_PASS,
            database=RDS_DB, connect_timeout=5
        )
        RDS_ENABLED = True
        _rds_conn.close()
        print(f"✅  RDS Connected — {RDS_HOST}:{RDS_PORT}/{RDS_DB}")
    else:
        print("ℹ️   RDS not configured — using SQLite (set RDS_HOST, RDS_USER, RDS_PASSWORD env vars)")
except Exception as e:
    print(f"ℹ️   RDS unavailable: {e} — using SQLite")
