"""
AES-256-CBC Encryption Utility
All tenant data stored encrypted — decrypted only when viewed by authorized user
"""
import os, base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

# 32-byte key — load from env in production
_raw = os.environ.get('ENCRYPTION_KEY', 'CloudPortalSecureKey2024ABCD1234')
ENCRYPTION_KEY = (_raw + '0'*32)[:32].encode('utf-8')

def encrypt_data(plaintext: str) -> str:
    """Encrypt string with AES-256-CBC → base64 output"""
    if not plaintext:
        return plaintext
    iv     = os.urandom(16)
    padder = padding.PKCS7(128).padder()
    padded = padder.update(plaintext.encode('utf-8')) + padder.finalize()
    cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
    enc    = cipher.encryptor()
    ct     = enc.update(padded) + enc.finalize()
    return base64.b64encode(iv + ct).decode('utf-8')

def decrypt_data(ciphertext: str) -> str:
    """Decrypt AES-256-CBC base64 string → plaintext"""
    if not ciphertext:
        return ciphertext
    try:
        raw      = base64.b64decode(ciphertext.encode('utf-8'))
        iv, ct   = raw[:16], raw[16:]
        cipher   = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
        dec      = cipher.decryptor()
        padded   = dec.update(ct) + dec.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        return (unpadder.update(padded) + unpadder.finalize()).decode('utf-8')
    except Exception:
        return '[Decryption Error]'

def is_encrypted(text: str) -> bool:
    """Check if a string looks like our base64 ciphertext"""
    if not text or len(text) < 24:
        return False
    try:
        base64.b64decode(text.encode('utf-8'))
        return True
    except Exception:
        return False
