import sqlite3, os

DB_PATH = os.path.join(os.path.dirname(__file__), 'instance', 'portal.db')

def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_schema():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS instances (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT UNIQUE NOT NULL,
            aws_id     TEXT DEFAULT 'local',
            region     TEXT DEFAULT 'local',
            status     TEXT DEFAULT 'running',
            ip_address TEXT DEFAULT 'N/A',
            plan       TEXT DEFAULT 't2.micro',
            source     TEXT DEFAULT 'portal',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT UNIQUE NOT NULL,
            email         TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            plain_password TEXT DEFAULT '',
            role          TEXT DEFAULT 'user',
            instance_id   INTEGER REFERENCES instances(id),
            is_active     INTEGER DEFAULT 1,
            created_at    TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS instance_data (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            instance_id INTEGER NOT NULL REFERENCES instances(id),
            title       TEXT NOT NULL,
            content     TEXT NOT NULL,
            data_type   TEXT DEFAULT 'general',
            created_by  INTEGER REFERENCES users(id),
            created_at  TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS activity_logs (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT DEFAULT (datetime('now')),
            user_id     INTEGER,
            username    TEXT,
            instance_id INTEGER,
            action      TEXT NOT NULL,
            status      TEXT NOT NULL,
            ip_address  TEXT,
            details     TEXT
        );
        """)
        for col in [
            "ALTER TABLE users ADD COLUMN plain_password TEXT DEFAULT ''",
            "ALTER TABLE instances ADD COLUMN source TEXT DEFAULT 'portal'",
        ]:
            try: conn.execute(col)
            except: pass
        conn.commit()
