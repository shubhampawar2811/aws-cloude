"""
AWS Cloud Portal — Fresh V5
Permissions:
  superadmin   → everything
  instance admin → same as superadmin WITHIN their instance
  user         → view/delete own data only

New:
  - view password for admin
  - add data to specific user within instance
  - all bugs fixed
"""
import os
from datetime import datetime, timezone, timedelta
from functools import wraps

import jwt as pyjwt
from flask import Flask, request, jsonify, render_template, g
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db, init_schema

app = Flask(__name__)
JWT_SECRET  = os.environ.get('JWT_SECRET', 'aws-portal-secret-2024')
JWT_EXPIRES = 3600

# ── AWS ───────────────────────────────────────────────────────────
AWS_ENABLED = False
_ec2        = None
_region     = os.environ.get('AWS_REGION', 'ap-south-1')
try:
    import boto3
    _k = os.environ.get('AWS_ACCESS_KEY_ID', '')
    _s = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    if _k and _s:
        _ec2 = boto3.client('ec2', region_name=_region, aws_access_key_id=_k, aws_secret_access_key=_s)
        _ec2.describe_regions(RegionNames=[_region])
        AWS_ENABLED = True
        print(f"✅  AWS Connected — {_region}")
    else:
        print("⚠️   Simulation mode — set AWS keys for real EC2")
except Exception as e:
    print(f"⚠️   AWS: {e}")

# ── DB ────────────────────────────────────────────────────────────
def db():
    if 'db' not in g:
        g.db = get_db()
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    d = g.pop('db', None)
    if d: d.close()

def make_token(p):
    d = dict(p)
    d['exp'] = datetime.now(timezone.utc) + timedelta(seconds=JWT_EXPIRES)
    return pyjwt.encode(d, JWT_SECRET, algorithm='HS256')

def jwt_required(f):
    @wraps(f)
    def w(*a, **kw):
        auth = request.headers.get('Authorization', '')
        if not auth.startswith('Bearer '):
            return jsonify({'error': 'Missing token'}), 401
        try:
            g.jwt_payload = pyjwt.decode(auth.split(' ',1)[1], JWT_SECRET, algorithms=['HS256'])
        except pyjwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expired'}), 401
        except Exception:
            return jsonify({'error': 'Invalid token'}), 401
        return f(*a, **kw)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a, **kw):
        if g.jwt_payload.get('role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*a, **kw)
    return w

def current_user():
    uid = g.jwt_payload['user_id']
    return db().execute(
        "SELECT u.*, i.name AS instance_name "
        "FROM users u LEFT JOIN instances i ON i.id=u.instance_id "
        "WHERE u.id=?", (uid,)
    ).fetchone()

def is_superadmin(u):
    return u['role'] == 'admin' and u['instance_id'] is None

def is_admin(u):
    return u['role'] == 'admin'

def log_action(action, status, user_id=None, username=None, instance_id=None, details=None):
    try:
        c = get_db()
        c.execute("INSERT INTO activity_logs (action,status,user_id,username,instance_id,ip_address,details) VALUES (?,?,?,?,?,?,?)",
                  (action, status, user_id, username, instance_id, request.remote_addr, details))
        c.commit(); c.close()
    except: pass

# ── AWS helpers ───────────────────────────────────────────────────
def aws_sync():
    if not AWS_ENABLED: return [], "AWS not connected"
    try:
        resp = _ec2.describe_instances()
        found = []
        conn = get_db()
        for res in resp['Reservations']:
            for inst in res['Instances']:
                if inst['State']['Name'] == 'terminated': continue
                aws_id = inst['InstanceId']
                ip     = inst.get('PublicIpAddress') or inst.get('PrivateIpAddress') or 'N/A'
                itype  = inst.get('InstanceType', 't2.micro')
                state  = inst['State']['Name']
                name   = aws_id
                for t in inst.get('Tags', []):
                    if t['Key'] == 'Name' and t['Value'].strip():
                        name = t['Value'].strip(); break
                ex = conn.execute("SELECT id FROM instances WHERE aws_id=?", (aws_id,)).fetchone()
                if ex:
                    conn.execute("UPDATE instances SET status=?,ip_address=? WHERE aws_id=?", (state,ip,aws_id))
                    conn.commit()
                    found.append({'aws_id':aws_id,'name':name,'status':'updated'})
                else:
                    base=name; c2=1
                    while conn.execute("SELECT id FROM instances WHERE name=?", (name,)).fetchone():
                        name=f"{base}-{c2}"; c2+=1
                    cur = conn.execute("INSERT INTO instances (name,aws_id,region,status,ip_address,plan,source) VALUES (?,?,?,?,?,?,?)",
                                       (name,aws_id,_region,state,ip,itype,'aws'))
                    conn.commit()
                    iid = cur.lastrowid
                    adm = name.lower().replace(' ','_').replace('-','_')+'_admin'
                    mail = adm+'@awsinstance.com'; pwd = 'Admin@1234'
                    try:
                        conn.execute("INSERT INTO users (username,email,password_hash,plain_password,role,instance_id) VALUES (?,?,?,?,?,?)",
                                     (adm,mail,generate_password_hash(pwd),pwd,'admin',iid))
                        conn.commit()
                    except: pass
                    found.append({'aws_id':aws_id,'name':name,'status':'imported','admin_username':adm,'admin_password':pwd})
        conn.close()
        return found, None
    except Exception as e:
        return [], str(e)

def aws_launch(name, itype='t2.micro'):
    if not AWS_ENABLED:
        return 'i-sim-'+name.lower().replace(' ','')[:12], 'Simulation', None
    try:
        r = _ec2.run_instances(ImageId='ami-0f5ee92e2d63afc18', InstanceType=itype,
                               MinCount=1, MaxCount=1,
                               TagSpecifications=[{'ResourceType':'instance','Tags':[{'Key':'Name','Value':name}]}])
        inst = r['Instances'][0]
        return inst['InstanceId'], inst.get('PublicIpAddress','Pending'), None
    except Exception as e:
        return None, None, str(e)

def aws_stop(aws_id):
    if not AWS_ENABLED or aws_id.startswith('i-sim'): return
    try: _ec2.stop_instances(InstanceIds=[aws_id])
    except: pass

def aws_terminate(aws_id):
    if not AWS_ENABLED or aws_id.startswith('i-sim'): return
    try: _ec2.terminate_instances(InstanceIds=[aws_id])
    except: pass

# ── Pages ─────────────────────────────────────────────────────────
@app.route('/')
def index(): return render_template('index.html')
@app.route('/login')
def login_page(): return render_template('login.html')
@app.route('/dashboard')
def dashboard(): return render_template('dashboard.html')
@app.route('/admin')
def admin_panel(): return render_template('admin.html')

# ── Auth ──────────────────────────────────────────────────────────
@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    row  = db().execute("SELECT * FROM users WHERE username=?", (data.get('username'),)).fetchone()
    if not row or not check_password_hash(row['password_hash'], data.get('password','')):
        log_action('LOGIN','FAILED', details=data.get('username'))
        return jsonify({'error': 'Invalid username or password'}), 401
    if not row['is_active']:
        return jsonify({'error': 'Account disabled'}), 403
    inst = None
    if row['instance_id']:
        inst = db().execute("SELECT * FROM instances WHERE id=?", (row['instance_id'],)).fetchone()
    token = make_token({'user_id': row['id'], 'instance_id': row['instance_id'], 'role': row['role']})
    log_action('LOGIN','SUCCESS', user_id=row['id'], username=row['username'], instance_id=row['instance_id'])
    return jsonify({
        'access_token': token,
        'user': {
            'id': row['id'], 'username': row['username'], 'email': row['email'],
            'role': row['role'], 'instance_id': row['instance_id'],
            'instance_name': inst['name'] if inst else None,
            'is_superadmin': row['instance_id'] is None and row['role'] == 'admin'
        }
    })

@app.route('/api/me')
@jwt_required
def me():
    u = current_user()
    if not u: return jsonify({'error': 'Not found'}), 404
    return jsonify({'id': u['id'], 'username': u['username'], 'email': u['email'],
                    'role': u['role'], 'instance_id': u['instance_id'],
                    'instance_name': u['instance_name'],
                    'is_superadmin': is_superadmin(u)})

# ── AWS Sync ──────────────────────────────────────────────────────
@app.route('/api/aws/sync', methods=['POST'])
@jwt_required
@admin_required
def sync_aws():
    # Both superadmin and instance admin can sync
    found, err = aws_sync()
    if err: return jsonify({'error': err}), 500
    return jsonify({'message': f'Sync done — {len(found)} instances', 'instances': found, 'aws_enabled': AWS_ENABLED})

@app.route('/api/aws/status')
@jwt_required
def aws_status():
    return jsonify({'aws_enabled': AWS_ENABLED, 'region': _region})

# ── Instances ─────────────────────────────────────────────────────
@app.route('/api/instances', methods=['GET'])
@jwt_required
def get_instances():
    u = current_user()
    if is_admin(u):
        if is_superadmin(u):
            rows = db().execute("SELECT * FROM instances ORDER BY created_at DESC").fetchall()
        else:
            rows = db().execute("SELECT * FROM instances WHERE id=?", (u['instance_id'],)).fetchall()
    else:
        rows = db().execute("SELECT * FROM instances WHERE id=?", (u['instance_id'],)).fetchall()
    result = []
    for r in rows:
        rec = dict(r)
        rec['user_count'] = db().execute("SELECT COUNT(*) AS c FROM users WHERE instance_id=?", (r['id'],)).fetchone()['c']
        rec['data_count'] = db().execute("SELECT COUNT(*) AS c FROM instance_data WHERE instance_id=?", (r['id'],)).fetchone()['c']
        result.append(rec)
    return jsonify({'instances': result, 'aws_enabled': AWS_ENABLED})

@app.route('/api/instances', methods=['POST'])
@jwt_required
@admin_required
def create_instance():
    # Both superadmin and instance admin can create
    u    = current_user()
    data = request.get_json() or {}
    name = data.get('name','').strip()
    if not name: return jsonify({'error': 'Instance name required'}), 400
    if db().execute("SELECT id FROM instances WHERE name=?", (name,)).fetchone():
        return jsonify({'error': 'Instance name already exists'}), 409
    plan = data.get('plan','t2.micro')
    aws_id, ip, err = aws_launch(name, plan)
    if err: return jsonify({'error': f'AWS Error: {err}'}), 500
    region = _region if AWS_ENABLED else 'local'
    cur = db().execute("INSERT INTO instances (name,aws_id,region,status,ip_address,plan,source) VALUES (?,?,?,?,?,?,?)",
                       (name,aws_id,region,'running',ip,plan,'portal'))
    db().commit()
    iid = cur.lastrowid
    adm_user = data.get('admin_username', name.lower().replace(' ','_')+'_admin')
    adm_mail = data.get('admin_email', adm_user+'@portal.com')
    adm_pass = data.get('admin_password','Admin@1234')
    try:
        db().execute("INSERT INTO users (username,email,password_hash,plain_password,role,instance_id) VALUES (?,?,?,?,?,?)",
                     (adm_user,adm_mail,generate_password_hash(adm_pass),adm_pass,'admin',iid))
        db().commit()
    except: pass
    log_action('CREATE_INSTANCE','SUCCESS', user_id=u['id'], username=u['username'], instance_id=iid, details=f"{name}|{aws_id}")
    return jsonify({'message': f'Instance "{name}" created', 'instance_id': iid, 'aws_id': aws_id,
                    'ip': ip, 'aws_enabled': AWS_ENABLED, 'admin_username': adm_user, 'admin_password': adm_pass}), 201

@app.route('/api/instances/<int:iid>/stop', methods=['POST'])
@jwt_required
@admin_required
def stop_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id=?", (iid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    aws_stop(row['aws_id'])
    db().execute("UPDATE instances SET status='stopped' WHERE id=?", (iid,))
    db().commit()
    return jsonify({'message': 'Stopped'})

@app.route('/api/instances/<int:iid>/start', methods=['POST'])
@jwt_required
@admin_required
def start_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id=?", (iid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    db().execute("UPDATE instances SET status='running' WHERE id=?", (iid,))
    db().commit()
    return jsonify({'message': 'Started'})

@app.route('/api/instances/<int:iid>', methods=['DELETE'])
@jwt_required
@admin_required
def delete_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id=?", (iid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    aws_terminate(row['aws_id'])
    db().execute("DELETE FROM instance_data WHERE instance_id=?", (iid,))
    db().execute("DELETE FROM users WHERE instance_id=?", (iid,))
    db().execute("DELETE FROM instances WHERE id=?", (iid,))
    db().commit()
    return jsonify({'message': 'Deleted'})

# ── Users ─────────────────────────────────────────────────────────
@app.route('/api/users', methods=['GET'])
@jwt_required
def get_users():
    u = current_user()
    if is_superadmin(u):
        rows = db().execute(
            "SELECT u.id,u.username,u.email,u.role,u.is_active,u.instance_id,u.created_at,u.plain_password,i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id=u.instance_id ORDER BY u.instance_id,u.id").fetchall()
    elif is_admin(u):
        rows = db().execute(
            "SELECT u.id,u.username,u.email,u.role,u.is_active,u.instance_id,u.created_at,u.plain_password,i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id=u.instance_id WHERE u.instance_id=? ORDER BY u.id",
            (u['instance_id'],)).fetchall()
    else:
        rows = db().execute(
            "SELECT u.id,u.username,u.email,u.role,u.is_active,u.instance_id,u.created_at,'' as plain_password,i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id=u.instance_id WHERE u.instance_id=? ORDER BY u.id",
            (u['instance_id'],)).fetchall()
    return jsonify({'users': [dict(r) for r in rows]})

@app.route('/api/users', methods=['POST'])
@jwt_required
@admin_required
def create_user():
    u    = current_user()
    data = request.get_json() or {}
    for f in ('username','email','password','instance_id'):
        if not data.get(f): return jsonify({'error': f'"{f}" is required'}), 400
    target_iid = int(data['instance_id'])
    if not is_superadmin(u) and target_iid != u['instance_id']:
        return jsonify({'error': 'Can only add users to your own instance'}), 403
    if not db().execute("SELECT id FROM instances WHERE id=?", (target_iid,)).fetchone():
        return jsonify({'error': 'Instance not found'}), 404
    if db().execute("SELECT id FROM users WHERE username=?", (data['username'],)).fetchone():
        return jsonify({'error': 'Username exists'}), 409
    if db().execute("SELECT id FROM users WHERE email=?", (data['email'],)).fetchone():
        return jsonify({'error': 'Email exists'}), 409
    pwd = data['password']
    cur = db().execute("INSERT INTO users (username,email,password_hash,plain_password,role,instance_id) VALUES (?,?,?,?,?,?)",
                       (data['username'],data['email'],generate_password_hash(pwd),pwd,data.get('role','user'),target_iid))
    db().commit()
    log_action('CREATE_USER','SUCCESS', user_id=u['id'], username=u['username'], instance_id=target_iid, details=f"New: {data['username']}")
    return jsonify({'message': 'User created', 'user_id': cur.lastrowid}), 201

@app.route('/api/users/<int:uid>', methods=['DELETE'])
@jwt_required
@admin_required
def delete_user(uid):
    u = current_user()
    if uid == u['id']: return jsonify({'error': 'Cannot delete yourself'}), 400
    row = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    if not is_superadmin(u) and row['instance_id'] != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    db().execute("DELETE FROM users WHERE id=?", (uid,))
    db().commit()
    return jsonify({'message': 'Deleted'})

@app.route('/api/users/<int:uid>/toggle', methods=['POST'])
@jwt_required
@admin_required
def toggle_user(uid):
    u   = current_user()
    row = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    if not is_superadmin(u) and row['instance_id'] != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    new = 0 if row['is_active'] else 1
    db().execute("UPDATE users SET is_active=? WHERE id=?", (new, uid))
    db().commit()
    return jsonify({'is_active': new, 'message': 'enabled' if new else 'disabled'})

# ── Data ──────────────────────────────────────────────────────────
@app.route('/api/data', methods=['GET'])
@jwt_required
def get_data():
    u   = current_user()
    uid = u['id']
    if is_admin(u):
        # Admin (super or instance) sees ALL data in their scope
        if is_superadmin(u):
            rows = db().execute(
                "SELECT d.*,i.name AS instance_name,us.username AS creator "
                "FROM instance_data d LEFT JOIN instances i ON i.id=d.instance_id "
                "LEFT JOIN users us ON us.id=d.created_by ORDER BY d.created_at DESC").fetchall()
        else:
            rows = db().execute(
                "SELECT d.*,i.name AS instance_name,us.username AS creator "
                "FROM instance_data d LEFT JOIN instances i ON i.id=d.instance_id "
                "LEFT JOIN users us ON us.id=d.created_by WHERE d.instance_id=? ORDER BY d.created_at DESC",
                (u['instance_id'],)).fetchall()
        result = []
        for r in rows:
            rec = dict(r)
            rec['can_view']   = True
            rec['can_delete'] = True
            result.append(rec)
    else:
        # Normal user — see all records in instance, view/delete only own
        rows = db().execute(
            "SELECT d.*,i.name AS instance_name,us.username AS creator "
            "FROM instance_data d LEFT JOIN instances i ON i.id=d.instance_id "
            "LEFT JOIN users us ON us.id=d.created_by WHERE d.instance_id=? ORDER BY d.created_at DESC",
            (u['instance_id'],)).fetchall()
        result = []
        for r in rows:
            rec = dict(r)
            is_owner = (r['created_by'] == uid)
            rec['can_view']   = is_owner
            rec['can_delete'] = is_owner
            if not is_owner:
                rec['content'] = '🔒 Private — only owner can view'
            result.append(rec)
    log_action('VIEW_DATA','SUCCESS', user_id=u['id'], username=u['username'], instance_id=u['instance_id'])
    return jsonify({'records': result})

@app.route('/api/data/<int:did>', methods=['GET'])
@jwt_required
def view_record(did):
    u   = current_user()
    row = db().execute(
        "SELECT d.*,i.name AS instance_name,us.username AS creator "
        "FROM instance_data d LEFT JOIN instances i ON i.id=d.instance_id "
        "LEFT JOIN users us ON us.id=d.created_by WHERE d.id=?", (did,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    if not is_admin(u):
        if row['instance_id'] != u['instance_id']:
            return jsonify({'error': 'Access denied'}), 403
        if row['created_by'] != u['id']:
            log_action('VIEW_DATA','BLOCKED', user_id=u['id'], username=u['username'],
                       details=f"Tried record {did} owned by {row['creator']}")
            return jsonify({'error': 'Access denied — not your record'}), 403
    elif not is_superadmin(u) and row['instance_id'] != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    return jsonify(dict(row))

@app.route('/api/data', methods=['POST'])
@jwt_required
def add_data():
    u    = current_user()
    data = request.get_json() or {}
    if not data.get('title') or not data.get('content'):
        return jsonify({'error': 'title and content required'}), 400
    iid = int(data.get('instance_id') or u['instance_id'] or 0)
    if not iid: return jsonify({'error': 'instance_id required'}), 400
    if not is_admin(u) and iid != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    # Admin can assign data to specific user; default is current user
    assigned_to = data.get('assigned_user_id') or u['id']
    if not is_admin(u):
        assigned_to = u['id']  # user can only add for themselves
    cur = db().execute(
        "INSERT INTO instance_data (instance_id,title,content,data_type,created_by) VALUES (?,?,?,?,?)",
        (iid, data['title'], data['content'], data.get('data_type','general'), assigned_to))
    db().commit()
    log_action('ADD_DATA','SUCCESS', user_id=u['id'], username=u['username'],
               instance_id=iid, details=f"'{data['title']}' for user_id:{assigned_to}")
    return jsonify({'message': 'Data added', 'id': cur.lastrowid}), 201

@app.route('/api/data/<int:did>', methods=['DELETE'])
@jwt_required
def delete_data(did):
    u   = current_user()
    row = db().execute("SELECT * FROM instance_data WHERE id=?", (did,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    if is_admin(u):
        if not is_superadmin(u) and row['instance_id'] != u['instance_id']:
            return jsonify({'error': 'Access denied'}), 403
    else:
        if row['instance_id'] != u['instance_id']:
            return jsonify({'error': 'Access denied'}), 403
        if row['created_by'] != u['id']:
            log_action('DELETE_DATA','BLOCKED', user_id=u['id'], username=u['username'],
                       details=f"Tried to delete record {did}")
            return jsonify({'error': 'Access denied — not your record'}), 403
    db().execute("DELETE FROM instance_data WHERE id=?", (did,))
    db().commit()
    log_action('DELETE_DATA','SUCCESS', user_id=u['id'], username=u['username'], instance_id=row['instance_id'])
    return jsonify({'message': 'Deleted'})

# ── Users by instance (for dropdown) ─────────────────────────────
@app.route('/api/instances/<int:iid>/users')
@jwt_required
@admin_required
def get_instance_users(iid):
    u = current_user()
    if not is_superadmin(u) and iid != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    rows = db().execute("SELECT id,username,role FROM users WHERE instance_id=? AND is_active=1 ORDER BY username", (iid,)).fetchall()
    return jsonify({'users': [dict(r) for r in rows]})

# ── Stats & Logs ──────────────────────────────────────────────────
@app.route('/api/stats')
@jwt_required
@admin_required
def get_stats():
    c = db(); u = current_user()
    if is_superadmin(u):
        return jsonify({'instances': c.execute("SELECT COUNT(*) AS n FROM instances").fetchone()['n'],
                        'users':     c.execute("SELECT COUNT(*) AS n FROM users").fetchone()['n'],
                        'data':      c.execute("SELECT COUNT(*) AS n FROM instance_data").fetchone()['n'],
                        'logs':      c.execute("SELECT COUNT(*) AS n FROM activity_logs").fetchone()['n'],
                        'running':   c.execute("SELECT COUNT(*) AS n FROM instances WHERE status='running'").fetchone()['n'],
                        'aws': AWS_ENABLED, 'region': _region})
    else:
        iid = u['instance_id']
        return jsonify({'instances': 1,
                        'users':   c.execute("SELECT COUNT(*) AS n FROM users WHERE instance_id=?", (iid,)).fetchone()['n'],
                        'data':    c.execute("SELECT COUNT(*) AS n FROM instance_data WHERE instance_id=?", (iid,)).fetchone()['n'],
                        'logs':    c.execute("SELECT COUNT(*) AS n FROM activity_logs WHERE instance_id=?", (iid,)).fetchone()['n'],
                        'running': 1, 'aws': AWS_ENABLED, 'region': _region})

@app.route('/api/logs')
@jwt_required
@admin_required
def get_logs():
    u = current_user()
    if is_superadmin(u):
        rows = db().execute("SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 100").fetchall()
    else:
        rows = db().execute("SELECT * FROM activity_logs WHERE instance_id=? ORDER BY timestamp DESC LIMIT 100", (u['instance_id'],)).fetchall()
    return jsonify({'logs': [dict(r) for r in rows]})

# ── Seed ──────────────────────────────────────────────────────────
def seed():
    conn = get_db()
    if conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()['c'] > 0:
        conn.close(); return
    conn.execute("INSERT INTO users (username,email,password_hash,plain_password,role,instance_id) VALUES (?,?,?,?,?,NULL)",
                 ('superadmin','superadmin@portal.com',generate_password_hash('Admin@1234'),'Admin@1234','admin'))
    for iname,plan in [('Alpha Corp','t2.micro'),('Beta Ltd','t2.small'),('Gamma Inc','t2.micro')]:
        conn.execute("INSERT INTO instances (name,aws_id,status,ip_address,plan,source) VALUES (?,?,?,?,?,?)",
                     (iname,'i-sim-'+iname.lower().replace(' ',''),'running','10.0.0.'+str(abs(hash(iname))%200+10),plan,'portal'))
    conn.commit()
    def iid(n): return conn.execute("SELECT id FROM instances WHERE name=?",(n,)).fetchone()['id']
    i1,i2,i3 = iid('Alpha Corp'),iid('Beta Ltd'),iid('Gamma Inc')
    for row in [
        ('alpha_admin','alpha@alphacorp.com','Admin@1234','admin',i1),
        ('alice','alice@alphacorp.com','Alice@1234','user',i1),
        ('john','john@alphacorp.com','John@1234','user',i1),
        ('beta_admin','admin@betaltd.com','Admin@1234','admin',i2),
        ('bob','bob@betaltd.com','Bob@1234','user',i2),
        ('gamma_admin','admin@gammainc.com','Admin@1234','admin',i3),
        ('charlie','charlie@gammainc.com','Charlie@1234','user',i3),
    ]:
        conn.execute("INSERT INTO users (username,email,password_hash,plain_password,role,instance_id) VALUES (?,?,?,?,?,?)",
                     (row[0],row[1],generate_password_hash(row[2]),row[2],row[3],row[4]))
    conn.commit()
    def uid(n): return conn.execute("SELECT id FROM users WHERE username=?",(n,)).fetchone()['id']
    for d in [
        (i1,'Alpha Sales Q1','Revenue $4.5M Growth 12%','financial',uid('alice')),
        (i1,'Alpha HR List','250 employees 3 offices','hr',uid('alpha_admin')),
        (i2,'Beta Roadmap','Q2: v2.0 launch Q3: AI','product',uid('bob')),
        (i2,'Beta Clients','Nike Adidas Puma signed','crm',uid('beta_admin')),
        (i3,'Gamma Memo','Board meeting merger vote','general',uid('charlie')),
    ]:
        conn.execute("INSERT INTO instance_data (instance_id,title,content,data_type,created_by) VALUES (?,?,?,?,?)",d)
    conn.commit(); conn.close()
    print("\n"+"="*60)
    print("✅  AWS Portal V5 Ready!")
    print("="*60)
    print("  superadmin   / Admin@1234  (Super Admin)")
    print("  alpha_admin  / Admin@1234  (Alpha Corp Admin)")
    print("  alice        / Alice@1234  (Alpha Corp User)")
    print("  bob          / Bob@1234    (Beta Ltd User)")
    print("="*60+"\n")

if __name__ == '__main__':
    init_schema()
    seed()
    app.run(debug=False, host='0.0.0.0', port=5000)
