"""
AWS Cloud Portal
- Create Instance from Web  → Real EC2 launches on AWS
- Create Instance from AWS  → Auto syncs to Web Portal
- Every Instance has Admin + Multiple Users
- Data added via Web is stored on THIS EC2 (same machine database)
- Super Admin sees everything
Run: python app.py
"""
import os
from datetime import datetime, timezone, timedelta
from functools import wraps

import jwt as pyjwt
from flask import Flask, request, jsonify, render_template, g
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db, init_schema

app = Flask(__name__)
JWT_SECRET  = os.environ.get('JWT_SECRET', 'aws-portal-secret-2024')
JWT_EXPIRES = 3600

# ── AWS Setup ─────────────────────────────────────────────────────
AWS_ENABLED = False
_ec2        = None
_region     = os.environ.get('AWS_REGION', 'ap-south-1')

try:
    import boto3
    _key    = os.environ.get('AWS_ACCESS_KEY_ID', '')
    _secret = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    if _key and _secret:
        _ec2 = boto3.client('ec2', region_name=_region,
                            aws_access_key_id=_key,
                            aws_secret_access_key=_secret)
        _ec2.describe_regions(RegionNames=[_region])
        AWS_ENABLED = True
        print(f"✅  AWS Connected — Region: {_region}")
    else:
        print("⚠️   AWS keys not set — Simulation mode ON")
        print("     export AWS_ACCESS_KEY_ID=xxx")
        print("     export AWS_SECRET_ACCESS_KEY=xxx")
except Exception as e:
    print(f"⚠️   AWS not available: {e}")

# ── DB Helpers ────────────────────────────────────────────────────
def db():
    if 'db' not in g:
        g.db = get_db()
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    d = g.pop('db', None)
    if d: d.close()

def make_token(payload):
    p = dict(payload)
    p['exp'] = datetime.now(timezone.utc) + timedelta(seconds=JWT_EXPIRES)
    return pyjwt.encode(p, JWT_SECRET, algorithm='HS256')

def jwt_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get('Authorization', '')
        if not auth.startswith('Bearer '):
            return jsonify({'error': 'Missing token'}), 401
        try:
            g.jwt_payload = pyjwt.decode(
                auth.split(' ', 1)[1], JWT_SECRET, algorithms=['HS256'])
        except pyjwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expired'}), 401
        except Exception:
            return jsonify({'error': 'Invalid token'}), 401
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if g.jwt_payload.get('role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return wrapper

def current_user():
    uid = g.jwt_payload['user_id']
    return db().execute(
        "SELECT u.*, i.name AS instance_name "
        "FROM users u LEFT JOIN instances i ON i.id=u.instance_id "
        "WHERE u.id=?", (uid,)
    ).fetchone()

def log_action(action, status, user_id=None, username=None,
               instance_id=None, details=None):
    try:
        c = get_db()
        c.execute(
            "INSERT INTO activity_logs "
            "(action,status,user_id,username,instance_id,ip_address,details) "
            "VALUES (?,?,?,?,?,?,?)",
            (action, status, user_id, username, instance_id,
             request.remote_addr, details))
        c.commit(); c.close()
    except Exception:
        pass

# ── AWS Functions ─────────────────────────────────────────────────
def aws_fetch_instances():
    """
    Fetch ALL EC2 instances from AWS Console.
    Called when Admin clicks 'Sync from AWS'.
    Adds any new AWS instances into our database automatically.
    """
    if not AWS_ENABLED:
        return [], "AWS not connected"
    try:
        resp  = _ec2.describe_instances()
        found = []
        conn  = get_db()
        for res in resp['Reservations']:
            for inst in res['Instances']:
                state = inst['State']['Name']
                if state == 'terminated':
                    continue
                aws_id = inst['InstanceId']
                ip     = inst.get('PublicIpAddress') or inst.get('PrivateIpAddress') or 'N/A'
                itype  = inst.get('InstanceType', 't2.micro')
                # Get Name tag
                name = aws_id  # default
                for tag in inst.get('Tags', []):
                    if tag['Key'] == 'Name' and tag['Value'].strip():
                        name = tag['Value'].strip()
                        break
                # Check if already in our database
                existing = conn.execute(
                    "SELECT id FROM instances WHERE aws_id=?", (aws_id,)
                ).fetchone()
                if existing:
                    # Update status and IP
                    conn.execute(
                        "UPDATE instances SET status=?, ip_address=? WHERE aws_id=?",
                        (state, ip, aws_id))
                    conn.commit()
                    found.append({'aws_id': aws_id, 'name': name, 'status': 'updated'})
                else:
                    # NEW instance from AWS — add to our database
                    # Make name unique
                    base_name = name
                    counter   = 1
                    while conn.execute("SELECT id FROM instances WHERE name=?",
                                       (name,)).fetchone():
                        name = f"{base_name}-{counter}"
                        counter += 1
                    cur = conn.execute(
                        "INSERT INTO instances "
                        "(name,aws_id,region,status,ip_address,plan,source) "
                        "VALUES (?,?,?,?,?,?,?)",
                        (name, aws_id, _region, state, ip, itype, 'aws'))
                    conn.commit()
                    iid = cur.lastrowid
                    # Auto create admin user for this instance
                    adm_user = name.lower().replace(' ', '_').replace('-', '_') + '_admin'
                    adm_mail = adm_user + '@awsinstance.com'
                    adm_pass = 'Admin@1234'
                    try:
                        conn.execute(
                            "INSERT INTO users "
                            "(username,email,password_hash,role,instance_id) "
                            "VALUES (?,?,?,?,?)",
                            (adm_user, adm_mail,
                             generate_password_hash(adm_pass), 'admin', iid))
                        conn.commit()
                    except Exception:
                        pass
                    found.append({
                        'aws_id':         aws_id,
                        'name':           name,
                        'status':         'imported',
                        'admin_username': adm_user,
                        'admin_password': adm_pass
                    })
        conn.close()
        return found, None
    except Exception as e:
        return [], str(e)

def aws_launch_instance(name, itype='t2.micro'):
    """
    Launch a REAL EC2 instance on AWS.
    Called when Admin creates instance from Web Portal.
    """
    if not AWS_ENABLED:
        # Simulation mode
        sim_id = 'i-sim-' + name.lower().replace(' ', '')[:12]
        return sim_id, 'Simulation (set AWS keys for real EC2)', None
    try:
        resp = _ec2.run_instances(
            ImageId='ami-0f5ee92e2d63afc18',  # Ubuntu 22.04 LTS ap-south-1
            InstanceType=itype,
            MinCount=1, MaxCount=1,
            TagSpecifications=[{
                'ResourceType': 'instance',
                'Tags': [{'Key': 'Name', 'Value': name}]
            }]
        )
        inst = resp['Instances'][0]
        aws_id = inst['InstanceId']
        ip     = inst.get('PublicIpAddress', 'Pending — check AWS Console')
        return aws_id, ip, None
    except Exception as e:
        return None, None, str(e)

def aws_stop(aws_id):
    if not AWS_ENABLED or aws_id.startswith('i-sim'): return
    try: _ec2.stop_instances(InstanceIds=[aws_id])
    except Exception: pass

def aws_terminate(aws_id):
    if not AWS_ENABLED or aws_id.startswith('i-sim'): return
    try: _ec2.terminate_instances(InstanceIds=[aws_id])
    except Exception: pass

# ── HTML Pages ────────────────────────────────────────────────────
@app.route('/')
def index():      return render_template('index.html')
@app.route('/login')
def login_page(): return render_template('login.html')
@app.route('/dashboard')
def dashboard():  return render_template('dashboard.html')
@app.route('/admin')
def admin_panel(): return render_template('admin.html')

# ── Auth ──────────────────────────────────────────────────────────
@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    row  = db().execute("SELECT * FROM users WHERE username=?",
                        (data.get('username'),)).fetchone()
    if not row or not check_password_hash(row['password_hash'],
                                          data.get('password', '')):
        log_action('LOGIN', 'FAILED', details=data.get('username'))
        return jsonify({'error': 'Invalid username or password'}), 401
    if not row['is_active']:
        return jsonify({'error': 'Account disabled by admin'}), 403
    inst = None
    if row['instance_id']:
        inst = db().execute("SELECT * FROM instances WHERE id=?",
                            (row['instance_id'],)).fetchone()
    token = make_token({'user_id':     row['id'],
                        'instance_id': row['instance_id'],
                        'role':        row['role']})
    log_action('LOGIN', 'SUCCESS', user_id=row['id'],
               username=row['username'], instance_id=row['instance_id'])
    return jsonify({
        'access_token': token,
        'user': {
            'id':            row['id'],
            'username':      row['username'],
            'email':         row['email'],
            'role':          row['role'],
            'instance_id':   row['instance_id'],
            'instance_name': inst['name'] if inst else None
        }
    })

@app.route('/api/me')
@jwt_required
def me():
    u = current_user()
    if not u: return jsonify({'error': 'Not found'}), 404
    return jsonify({'id': u['id'], 'username': u['username'],
                    'email': u['email'], 'role': u['role'],
                    'instance_id': u['instance_id'],
                    'instance_name': u['instance_name']})

# ── AWS Sync API ──────────────────────────────────────────────────
@app.route('/api/aws/sync', methods=['POST'])
@jwt_required
@admin_required
def sync_from_aws():
    """
    Pull ALL instances from AWS Console into Web Portal.
    New AWS instances are added automatically with admin user.
    """
    found, err = aws_fetch_instances()
    if err:
        return jsonify({'error': err}), 500
    return jsonify({
        'message': f'Sync complete — {len(found)} instances processed',
        'instances': found,
        'aws_enabled': AWS_ENABLED
    })

@app.route('/api/aws/status')
@jwt_required
@admin_required
def aws_status():
    return jsonify({'aws_enabled': AWS_ENABLED, 'region': _region})

# ── Instances API ─────────────────────────────────────────────────
@app.route('/api/instances', methods=['GET'])
@jwt_required
def get_instances():
    u = current_user()
    if u['role'] == 'admin':
        rows = db().execute(
            "SELECT * FROM instances ORDER BY created_at DESC").fetchall()
    else:
        rows = db().execute(
            "SELECT * FROM instances WHERE id=?",
            (u['instance_id'],)).fetchall()
    result = []
    for r in rows:
        rec = dict(r)
        rec['user_count'] = db().execute(
            "SELECT COUNT(*) AS c FROM users WHERE instance_id=?",
            (r['id'],)).fetchone()['c']
        rec['data_count'] = db().execute(
            "SELECT COUNT(*) AS c FROM instance_data WHERE instance_id=?",
            (r['id'],)).fetchone()['c']
        result.append(rec)
    return jsonify({'instances': result, 'aws_enabled': AWS_ENABLED})

@app.route('/api/instances', methods=['POST'])
@jwt_required
@admin_required
def create_instance():
    """
    Create instance from Web Portal → launches REAL EC2 on AWS.
    Also creates admin user automatically.
    """
    u    = current_user()
    data = request.get_json() or {}
    name = data.get('name', '').strip()
    if not name:
        return jsonify({'error': 'Instance name is required'}), 400
    if db().execute("SELECT id FROM instances WHERE name=?",
                    (name,)).fetchone():
        return jsonify({'error': 'Instance name already exists'}), 409

    plan           = data.get('plan', 't2.micro')
    aws_id, ip, err = aws_launch_instance(name, plan)
    if err:
        return jsonify({'error': f'AWS Error: {err}'}), 500

    status = 'running' if not (aws_id or '').startswith('error') else 'error'
    region = _region if AWS_ENABLED else 'local'
    source = 'portal'

    cur = db().execute(
        "INSERT INTO instances (name,aws_id,region,status,ip_address,plan,source) "
        "VALUES (?,?,?,?,?,?,?)",
        (name, aws_id, region, status, ip, plan, source))
    db().commit()
    iid = cur.lastrowid

    # Auto-create admin user for this instance
    adm_user = data.get('admin_username',
                         name.lower().replace(' ', '_') + '_admin')
    adm_mail = data.get('admin_email', adm_user + '@portal.com')
    adm_pass = data.get('admin_password', 'Admin@1234')
    try:
        db().execute(
            "INSERT INTO users (username,email,password_hash,role,instance_id) "
            "VALUES (?,?,?,?,?)",
            (adm_user, adm_mail,
             generate_password_hash(adm_pass), 'admin', iid))
        db().commit()
    except Exception:
        pass

    log_action('CREATE_INSTANCE', 'SUCCESS',
               user_id=u['id'], username=u['username'],
               instance_id=iid,
               details=f"Name:{name} AWS:{aws_id} Source:portal")
    return jsonify({
        'message':        f'Instance "{name}" created' + (' on AWS!' if AWS_ENABLED else ' (Simulation)'),
        'instance_id':    iid,
        'aws_id':         aws_id,
        'ip':             ip,
        'aws_enabled':    AWS_ENABLED,
        'admin_username': adm_user,
        'admin_password': adm_pass
    }), 201

@app.route('/api/instances/<int:iid>/stop', methods=['POST'])
@jwt_required
@admin_required
def stop_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id=?", (iid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    aws_stop(row['aws_id'])
    db().execute("UPDATE instances SET status='stopped' WHERE id=?", (iid,))
    db().commit()
    return jsonify({'message': 'Instance stopped'})

@app.route('/api/instances/<int:iid>/start', methods=['POST'])
@jwt_required
@admin_required
def start_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id=?", (iid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    db().execute("UPDATE instances SET status='running' WHERE id=?", (iid,))
    db().commit()
    return jsonify({'message': 'Instance started'})

@app.route('/api/instances/<int:iid>', methods=['DELETE'])
@jwt_required
@admin_required
def delete_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id=?", (iid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    aws_terminate(row['aws_id'])
    db().execute("DELETE FROM instance_data WHERE instance_id=?", (iid,))
    db().execute("DELETE FROM users WHERE instance_id=?", (iid,))
    db().execute("DELETE FROM instances WHERE id=?", (iid,))
    db().commit()
    return jsonify({'message': 'Instance deleted'})

# ── Users API ─────────────────────────────────────────────────────
@app.route('/api/users', methods=['GET'])
@jwt_required
def get_users():
    u = current_user()
    if u['role'] == 'admin':
        rows = db().execute(
            "SELECT u.id,u.username,u.email,u.role,u.is_active,"
            "u.instance_id,u.created_at,i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id=u.instance_id "
            "ORDER BY u.instance_id,u.id"
        ).fetchall()
    else:
        rows = db().execute(
            "SELECT u.id,u.username,u.email,u.role,u.is_active,"
            "u.instance_id,u.created_at,i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id=u.instance_id "
            "WHERE u.instance_id=? ORDER BY u.id",
            (u['instance_id'],)
        ).fetchall()
    return jsonify({'users': [dict(r) for r in rows]})

@app.route('/api/users', methods=['POST'])
@jwt_required
@admin_required
def create_user():
    u    = current_user()
    data = request.get_json() or {}
    for f in ('username', 'email', 'password', 'instance_id'):
        if not data.get(f):
            return jsonify({'error': f'Field "{f}" is required'}), 400
    if not db().execute("SELECT id FROM instances WHERE id=?",
                        (data['instance_id'],)).fetchone():
        return jsonify({'error': 'Instance not found'}), 404
    if db().execute("SELECT id FROM users WHERE username=?",
                    (data['username'],)).fetchone():
        return jsonify({'error': 'Username already exists'}), 409
    if db().execute("SELECT id FROM users WHERE email=?",
                    (data['email'],)).fetchone():
        return jsonify({'error': 'Email already exists'}), 409
    cur = db().execute(
        "INSERT INTO users (username,email,password_hash,role,instance_id) "
        "VALUES (?,?,?,?,?)",
        (data['username'], data['email'],
         generate_password_hash(data['password']),
         data.get('role', 'user'), data['instance_id']))
    db().commit()
    log_action('CREATE_USER', 'SUCCESS',
               user_id=u['id'], username=u['username'],
               instance_id=data['instance_id'],
               details=f"New user: {data['username']}")
    return jsonify({'message': 'User created', 'user_id': cur.lastrowid}), 201

@app.route('/api/users/<int:uid>', methods=['DELETE'])
@jwt_required
@admin_required
def delete_user(uid):
    u = current_user()
    if uid == u['id']:
        return jsonify({'error': 'Cannot delete yourself'}), 400
    if not db().execute("SELECT id FROM users WHERE id=?", (uid,)).fetchone():
        return jsonify({'error': 'User not found'}), 404
    db().execute("DELETE FROM users WHERE id=?", (uid,))
    db().commit()
    return jsonify({'message': 'User deleted'})

@app.route('/api/users/<int:uid>/toggle', methods=['POST'])
@jwt_required
@admin_required
def toggle_user(uid):
    row = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    new_val = 0 if row['is_active'] else 1
    db().execute("UPDATE users SET is_active=? WHERE id=?", (new_val, uid))
    db().commit()
    return jsonify({'is_active': new_val,
                    'message': 'enabled' if new_val else 'disabled'})

# ── Data API ──────────────────────────────────────────────────────
@app.route('/api/data', methods=['GET'])
@jwt_required
def get_data():
    u = current_user()
    if u['role'] == 'admin':
        rows = db().execute(
            "SELECT d.*,i.name AS instance_name,u.username AS creator "
            "FROM instance_data d "
            "LEFT JOIN instances i ON i.id=d.instance_id "
            "LEFT JOIN users u ON u.id=d.created_by "
            "ORDER BY d.created_at DESC"
        ).fetchall()
    else:
        # User sees ONLY their instance data
        rows = db().execute(
            "SELECT d.*,i.name AS instance_name,u.username AS creator "
            "FROM instance_data d "
            "LEFT JOIN instances i ON i.id=d.instance_id "
            "LEFT JOIN users u ON u.id=d.created_by "
            "WHERE d.instance_id=? ORDER BY d.created_at DESC",
            (u['instance_id'],)
        ).fetchall()
    log_action('VIEW_DATA', 'SUCCESS',
               user_id=u['id'], username=u['username'],
               instance_id=u['instance_id'])
    return jsonify({'records': [dict(r) for r in rows]})

@app.route('/api/data', methods=['POST'])
@jwt_required
def add_data():
    """
    Data added here is stored in SQLite database
    which lives on THIS EC2 machine's filesystem.
    So data IS on the AWS instance. ✅
    """
    u    = current_user()
    data = request.get_json() or {}
    if not data.get('title') or not data.get('content'):
        return jsonify({'error': 'title and content are required'}), 400
    iid = int(data.get('instance_id') or u['instance_id'] or 0)
    if not iid:
        return jsonify({'error': 'instance_id is required'}), 400
    if u['role'] != 'admin' and iid != u['instance_id']:
        log_action('DATA_ACCESS', 'BLOCKED',
                   user_id=u['id'], username=u['username'],
                   details='Cross-instance data attempt blocked')
        return jsonify({'error': 'Access denied — you can only add to your instance'}), 403
    cur = db().execute(
        "INSERT INTO instance_data "
        "(instance_id,title,content,data_type,created_by) VALUES (?,?,?,?,?)",
        (iid, data['title'], data['content'],
         data.get('data_type', 'general'), u['id']))
    db().commit()
    log_action('ADD_DATA', 'SUCCESS',
               user_id=u['id'], username=u['username'], instance_id=iid,
               details=f"Title: {data['title']}")
    return jsonify({'message': 'Data added and stored on this EC2 instance',
                    'id': cur.lastrowid}), 201

@app.route('/api/data/<int:did>', methods=['DELETE'])
@jwt_required
def delete_data(did):
    u   = current_user()
    row = db().execute("SELECT * FROM instance_data WHERE id=?", (did,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    if u['role'] != 'admin' and row['instance_id'] != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    db().execute("DELETE FROM instance_data WHERE id=?", (did,))
    db().commit()
    return jsonify({'message': 'Deleted'})

# ── Stats & Logs ──────────────────────────────────────────────────
@app.route('/api/stats')
@jwt_required
@admin_required
def get_stats():
    c = db()
    return jsonify({
        'instances': c.execute("SELECT COUNT(*) AS n FROM instances").fetchone()['n'],
        'users':     c.execute("SELECT COUNT(*) AS n FROM users").fetchone()['n'],
        'data':      c.execute("SELECT COUNT(*) AS n FROM instance_data").fetchone()['n'],
        'logs':      c.execute("SELECT COUNT(*) AS n FROM activity_logs").fetchone()['n'],
        'running':   c.execute("SELECT COUNT(*) AS n FROM instances WHERE status='running'").fetchone()['n'],
        'aws':       AWS_ENABLED,
        'region':    _region
    })

@app.route('/api/logs')
@jwt_required
@admin_required
def get_logs():
    rows = db().execute(
        "SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 100"
    ).fetchall()
    return jsonify({'logs': [dict(r) for r in rows]})

# ── Seed Demo Data ────────────────────────────────────────────────
def seed():
    conn = get_db()
    if conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()['c'] > 0:
        conn.close(); return

    # Super admin
    conn.execute(
        "INSERT INTO users (username,email,password_hash,role,instance_id) "
        "VALUES (?,?,?,?,NULL)",
        ('superadmin', 'superadmin@portal.com',
         generate_password_hash('Admin@1234'), 'admin'))

    # 3 demo instances
    for iname, plan in [('Alpha Corp', 't2.micro'),
                         ('Beta Ltd',   't2.small'),
                         ('Gamma Inc',  't2.micro')]:
        conn.execute(
            "INSERT INTO instances (name,aws_id,status,ip_address,plan,source) "
            "VALUES (?,?,?,?,?,?)",
            (iname,
             'i-sim-' + iname.lower().replace(' ', ''),
             'running',
             '10.0.0.' + str(abs(hash(iname)) % 200 + 10),
             plan, 'portal'))
    conn.commit()

    def iid(name):
        return conn.execute(
            "SELECT id FROM instances WHERE name=?", (name,)
        ).fetchone()['id']

    i1, i2, i3 = iid('Alpha Corp'), iid('Beta Ltd'), iid('Gamma Inc')

    demo_users = [
        ('alpha_admin', 'alpha@alphacorp.com', 'Admin@1234', 'admin', i1),
        ('alice',       'alice@alphacorp.com', 'Alice@1234', 'user',  i1),
        ('john',        'john@alphacorp.com',  'John@1234',  'user',  i1),
        ('beta_admin',  'admin@betaltd.com',   'Admin@1234', 'admin', i2),
        ('bob',         'bob@betaltd.com',     'Bob@1234',   'user',  i2),
        ('gamma_admin', 'admin@gammainc.com',  'Admin@1234', 'admin', i3),
        ('charlie',     'charlie@gammainc.com','Charlie@1234','user', i3),
    ]
    for row in demo_users:
        conn.execute(
            "INSERT INTO users (username,email,password_hash,role,instance_id) "
            "VALUES (?,?,?,?,?)",
            (row[0], row[1], generate_password_hash(row[2]), row[3], row[4]))
    conn.commit()

    def uid(uname):
        return conn.execute(
            "SELECT id FROM users WHERE username=?", (uname,)
        ).fetchone()['id']

    demo_data = [
        (i1, 'Alpha Sales Q1', 'Revenue $4.5M Growth 12%',  'financial', uid('alice')),
        (i1, 'Alpha HR List',  '250 employees 3 offices',   'hr',        uid('alpha_admin')),
        (i2, 'Beta Roadmap',   'Q2: v2.0 launch Q3: AI',    'product',   uid('bob')),
        (i2, 'Beta Clients',   'Nike Adidas Puma signed',   'crm',       uid('beta_admin')),
        (i3, 'Gamma Memo',     'Board meeting merger vote',  'general',   uid('charlie')),
    ]
    for d in demo_data:
        conn.execute(
            "INSERT INTO instance_data "
            "(instance_id,title,content,data_type,created_by) VALUES (?,?,?,?,?)", d)
    conn.commit(); conn.close()

    print("\n" + "="*62)
    print("✅  AWS Portal Ready!")
    print("="*62)
    print("  SUPER ADMIN  :  superadmin   /  Admin@1234")
    print("  Alpha Admin  :  alpha_admin  /  Admin@1234  (Alpha Corp)")
    print("  Alpha User   :  alice        /  Alice@1234  (Alpha Corp)")
    print("  Beta User    :  bob          /  Bob@1234    (Beta Ltd)")
    print("  Gamma User   :  charlie      /  Charlie@1234(Gamma Inc)")
    print("="*62)
    print("  🌐  Open → http://YOUR-EC2-IP:5000")
    print("  📂  Database stored at: instance/portal.db (on this EC2)")
    if AWS_ENABLED:
        print(f"  ☁️   AWS Connected — Region: {_region}")
        print("  🔄  Click 'Sync from AWS' to import your EC2 instances")
    else:
        print("  ⚠️   AWS not connected — set keys to enable real EC2")
    print("="*62 + "\n")

if __name__ == '__main__':
    init_schema()
    seed()
    app.run(debug=False, host='0.0.0.0', port=5000)
